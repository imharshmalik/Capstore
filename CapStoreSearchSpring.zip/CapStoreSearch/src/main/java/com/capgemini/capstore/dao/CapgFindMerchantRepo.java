package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.capgemini.capstore.beans.CapgMerchant;

@Repository
public interface CapgFindMerchantRepo extends JpaRepository<CapgMerchant, Integer> {

	public List<CapgMerchant> findByMerchantName(String name);
	
}
