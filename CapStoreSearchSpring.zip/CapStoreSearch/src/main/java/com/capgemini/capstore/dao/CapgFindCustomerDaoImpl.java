package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.capgemini.capstore.beans.CapgCustomer;
import com.capgemini.capstore.exceptions.InvalidInputException;

@Repository
public class CapgFindCustomerDaoImpl implements ICapgFindCustomerDao{
	
	@Autowired
	CapgFindCustomerRepo customerRepo;
	
	//Search Customer
		public List<CapgCustomer> getCustomerByName(String customerName) throws InvalidInputException {
			if (customerRepo.findByCustomerName(customerName) != null)
				return customerRepo.findByCustomerName(customerName);
			else
				throw new InvalidInputException();
		}
		
		public List<CapgCustomer> findAllCustomers() throws InvalidInputException {
			return customerRepo.findAll();
		}

}
