package com.capgemini.capstore.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.capgemini.capstore.beans.CapgMerchant;
import com.capgemini.capstore.exceptions.InvalidInputException;

@Repository
public class CapgFindMerchantDaoImpl implements ICapgFindMerchantDao{

	@Autowired
	CapgFindMerchantRepo merchantRepo;
	@Override
	public List<CapgMerchant> getMerchantByName(String merchantName) throws InvalidInputException {	
		if (merchantRepo.findByMerchantName(merchantName) != null)
			return merchantRepo.findByMerchantName(merchantName);
		else
			throw new InvalidInputException();
	}

	@Override
	public List<CapgMerchant> findAllMerchants() throws InvalidInputException {
	
		return merchantRepo.findAll();
	}

}
