package com.capgemini.capstore.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.CapgCustomer;
import com.capgemini.capstore.beans.CapgMerchant;
import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.exceptions.InvalidInputException;
import com.capgemini.capstore.services.ICapgCustomerService;
import com.capgemini.capstore.services.ICapgMerchantService;
import com.capgemini.capstore.services.ICapgProductService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class CapgController {

	@Autowired
	private ICapgProductService productService;
	
	@Autowired
	private ICapgCustomerService customerService;
	
	@Autowired
	private ICapgMerchantService merchantService;

	
	//Admin/Customer Searches Product
	@RequestMapping(value = "/getProductByName/{productName}")
	public CapgProduct getProductByName(@PathVariable String productName) {
		CapgProduct product = null;
		try {
			product = productService.getProductByName(productName);
		} catch (InvalidInputException e) {
			return product;
		}
		return product;
	}

	@RequestMapping(value = "/getProductById/{productId}")
	public CapgProduct getProductById(@PathVariable int productId) {
		CapgProduct product = null;
		try {
			product = productService.getProductById(productId);
		} catch (InvalidInputException e) {
			return product;
		}
		return product;
	}

	@RequestMapping(value = "/getProductByType/{productType}")
	public List<CapgProduct> getProductByType(@PathVariable String productType) {
		List<CapgProduct> products = null;
		try {
			products = productService.getProductByType(productType);
		} catch (InvalidInputException e) {
			return products;
		}
		return products;
	}

	@RequestMapping(value = "/getProductByCategory/{productCategory}")
	public List<CapgProduct> getProductByCategory(@PathVariable String productCategory) {
		List<CapgProduct> products = null;
		try {
			products = productService.getProductByCategory(productCategory);
		} catch (InvalidInputException e) {
			return products;
		}
		return products;
	}
	
	//Merchant searches product
	@RequestMapping(value="/getProductByMerchantId/{merchantId}")
	public List<CapgProduct> getProductByMerchantId(@PathVariable int merchantId)
	{
		List<CapgProduct> products = null;
		try {
			products = productService.getProductByMerchantId(merchantId);
		} catch (InvalidInputException e) {
			return products;
		}
		return products;
	}

	@GetMapping(value = "/getAllProducts")
	public List<CapgProduct> getAllProducts() {
		List<CapgProduct> products = null;
		
		try {
			products = productService.findAllProducts();
		} catch (InvalidInputException e) {
			e.printStackTrace();
		}
		return products;
	}


	//Admin Searches Customer
	@RequestMapping(value = "/getCustomerByName/{customerName}")
	public List<CapgCustomer> getCustomerByName(@PathVariable String customerName) {
		List<CapgCustomer> customers = null;
		try {
			customers = customerService.getCustomerByName(customerName);
		} catch (InvalidInputException e) {
			return customers;
		}
		return customers;
	}
	
	@RequestMapping(value = "/getAllCustomers")
	public List<CapgCustomer> getAllCustomers() {
		List<CapgCustomer> customers = null;
		try {
			customers = customerService.findAllCustomers();
		} catch (InvalidInputException e) {
			e.printStackTrace();
		}
		return customers;
	}
	
	//Admin Searches Merchant
		@RequestMapping(value = "/getMerchantByName/{merchantName}")
		public List<CapgMerchant> getMerchantByName(@PathVariable String merchantName) {
			List<CapgMerchant> merchants = null;
			try {
				merchants = merchantService.getMerchantByName(merchantName);
			} catch (InvalidInputException e) {
				return merchants;
			}
			return merchants;
		}
		
		@RequestMapping(value = "/getAllMerchants")
		public List<CapgMerchant> getAllMerchants() {
			List<CapgMerchant> merchants = null;
			try {
				merchants = merchantService.findAllMerchants();
			} catch (InvalidInputException e) {
				e.printStackTrace();
			}
			return merchants;
		}
}
