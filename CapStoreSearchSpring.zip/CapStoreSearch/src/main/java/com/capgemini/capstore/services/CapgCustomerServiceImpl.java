package com.capgemini.capstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.CapgCustomer;
import com.capgemini.capstore.dao.ICapgFindCustomerDao;
import com.capgemini.capstore.exceptions.InvalidInputException;

@Service
public class CapgCustomerServiceImpl implements ICapgCustomerService {
	
	@Autowired
	ICapgFindCustomerDao customerdao;
	
	//Search Customer
	public List<CapgCustomer> getCustomerByName(String customerName) throws InvalidInputException {
		if (customerdao.getCustomerByName(customerName) != null)
			return customerdao.getCustomerByName(customerName);
		else
			throw new InvalidInputException();
	}
	
	public List<CapgCustomer> findAllCustomers() throws InvalidInputException {
		return customerdao.findAllCustomers();
	}
}
