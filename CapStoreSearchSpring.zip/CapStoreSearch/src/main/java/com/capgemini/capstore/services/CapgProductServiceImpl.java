package com.capgemini.capstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.dao.ICapgMerchantProductDao;
import com.capgemini.capstore.dao.ICapgProductDao;
import com.capgemini.capstore.exceptions.InvalidInputException;

@Service
public class CapgProductServiceImpl implements ICapgProductService{

	@Autowired
	ICapgProductDao productdao;
	@Autowired
	ICapgMerchantProductDao merchantProductdao;

	//Search Product
	public CapgProduct getProductByName(String productName) throws InvalidInputException {
		if (productdao.getProductByName(productName) != null)
			return productdao.getProductByName(productName);
		else
			throw new InvalidInputException();
	}

	public CapgProduct getProductById(int productId) throws InvalidInputException {
		if (productdao.getProductById(productId) != null)
			return productdao.getProductById(productId);
		else
			throw new InvalidInputException();
	}

	public List<CapgProduct> getProductByType(String productType) throws InvalidInputException {
		if (productdao.getProductByType(productType) != null)
			return productdao.getProductByType(productType);
		else
			throw new InvalidInputException();
	}

	public List<CapgProduct> getProductByCategory(String productCategory) throws InvalidInputException {
		if (productdao.getProductByCategory(productCategory) != null)
			return productdao.getProductByCategory(productCategory);
		else
			throw new InvalidInputException();
	}
	
	public List<CapgProduct> getProductByMerchantId(int merchantId) throws InvalidInputException {
		if (merchantProductdao.getProductByMerchantId(merchantId) != null) {
			System.out.println(merchantProductdao.getProductByMerchantId(merchantId));
			return merchantProductdao.getProductByMerchantId(merchantId);}
		else
			throw new InvalidInputException();
	}

	public List<CapgProduct> findAllProducts() throws InvalidInputException {
		return productdao.findAllProducts();
	}
	

}
