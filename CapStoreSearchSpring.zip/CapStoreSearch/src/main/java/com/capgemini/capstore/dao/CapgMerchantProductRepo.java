package com.capgemini.capstore.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.capgemini.capstore.beans.CapgProduct;

@Repository
public interface CapgMerchantProductRepo extends JpaRepository<CapgProduct, Integer> {

	public List<CapgProduct> findByMerchantId (int merchantId);

	
}
