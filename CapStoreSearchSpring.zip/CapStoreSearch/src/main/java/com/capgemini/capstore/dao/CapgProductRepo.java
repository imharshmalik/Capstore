package com.capgemini.capstore.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.capgemini.capstore.beans.CapgProduct;

@Repository
public interface CapgProductRepo extends JpaRepository<CapgProduct, Integer> {
	
	public CapgProduct findByProductId(int productId);
	
	public CapgProduct findByProductName(String productName);
	
	public List<CapgProduct> findByProductType(String productType);
	
	public List<CapgProduct> findByProductCategory(String productCategory);
	
	public List<CapgProduct> findByMerchantId (int merchantId);
	
}
