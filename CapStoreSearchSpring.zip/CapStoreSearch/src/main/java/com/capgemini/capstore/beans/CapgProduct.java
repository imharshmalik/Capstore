package com.capgemini.capstore.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="capgproduct")
public class CapgProduct {
      
    @Column(name="product_brand")
    private String productBrand;
    @Column(name="product_category")
    private String productCategory;
    @Id
    @SequenceGenerator(name="seq" , sequenceName = "product_seq")
    @GeneratedValue(generator = "seq")
    @Column(name="product_id")
    private int productId;
    @Column(name="product_name")
    private String productName;
    @Column(name="product_price")
    private double productPrice;
    @Column(name="product_quantity")
    private int productQuantity;
    @Column(name="product_rating")
    private double productRating;
    @Column(name="product_type")
    private String productType;
    @Column(name="merchant_id")
    private int merchantId;
 
    public String getProductBrand() {
        return productBrand;
    }
    public void setProductBrand(String productBrand) {
        this.productBrand = productBrand;
    }
    public String getProductCategory() {
        return productCategory;
    }
    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }
    public int getProductId() {
        return productId;
    }
    public void setProductId(int productId) {
        this.productId = productId;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public double getProductPrice() {
        return productPrice;
    }
    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }
    public int getProductQuantity() {
        return productQuantity;
    }
    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }
    public double getProductRating() {
        return productRating;
    }
    public void setProductRating(double productRating) {
        this.productRating = productRating;
    }
    public String getProductType() {
        return productType;
    }
    public void setProductType(String productType) {
        this.productType = productType;
    }
    public int getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(int merchantId) {
        this.merchantId = merchantId;
    }
	@Override
	public String toString() {
		return "CapgProduct [productBrand=" + productBrand + ", productCategory=" + productCategory + ", productId="
				+ productId + ", productName=" + productName + ", productPrice=" + productPrice + ", productQuantity="
				+ productQuantity + ", productRating=" + productRating + ", productType=" + productType
				+ ", merchantId=" + merchantId + "]";
	}
      
}