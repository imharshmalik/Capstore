package com.capgemini.capstore.dao;

import java.util.List;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.exceptions.InvalidInputException;

public interface ICapgMerchantProductDao {

	public List<CapgProduct> getProductByMerchantId(int merchantId) throws InvalidInputException;
}
