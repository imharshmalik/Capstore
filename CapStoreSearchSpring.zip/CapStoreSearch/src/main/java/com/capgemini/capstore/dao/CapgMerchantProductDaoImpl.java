package com.capgemini.capstore.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.exceptions.InvalidInputException;

@Repository
public class CapgMerchantProductDaoImpl implements ICapgMerchantProductDao {

	@Autowired
	CapgMerchantProductRepo merchantRepo;
	
	public List<CapgProduct> getProductByMerchantId(int merchantId) throws InvalidInputException {
		if (merchantRepo.findByMerchantId(merchantId) != null) {
			System.out.println(merchantRepo.findByMerchantId(merchantId));
			return merchantRepo.findByMerchantId(merchantId);
		} else
			throw new InvalidInputException();
	}
}
