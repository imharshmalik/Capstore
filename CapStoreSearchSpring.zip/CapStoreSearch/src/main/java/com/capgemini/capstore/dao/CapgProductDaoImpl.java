package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.exceptions.InvalidInputException;

@Repository
public class CapgProductDaoImpl implements ICapgProductDao{

	@Autowired 
	CapgProductRepo productRepo;
	@Override
	public CapgProduct getProductByName(String productName) throws InvalidInputException {
		if (productRepo.findByProductName(productName) != null)
			return productRepo.findByProductName(productName);
		else
			throw new InvalidInputException();
	}

	@Override
	public CapgProduct getProductById(int productId) throws InvalidInputException {
		if (productRepo.findByProductId(productId) != null)
			return productRepo.findByProductId(productId);
		else
			throw new InvalidInputException();
	}

	@Override
	public List<CapgProduct> getProductByType(String productType) throws InvalidInputException {
		if (productRepo.findByProductType(productType) != null)
			return productRepo.findByProductType(productType);
		else
			throw new InvalidInputException();
	}

	@Override
	public List<CapgProduct> getProductByCategory(String productCategory) throws InvalidInputException {
		if (productRepo.findByProductCategory(productCategory) != null)
			return productRepo.findByProductCategory(productCategory);
		else
			throw new InvalidInputException();
	}

	@Override
	public List<CapgProduct> getProductByMerchantId(int merchantId) throws InvalidInputException {
		if (productRepo.findByMerchantId(merchantId) != null) {
			System.out.println(productRepo.findByMerchantId(merchantId));
			return productRepo.findByMerchantId(merchantId);}
		else
			throw new InvalidInputException();
	}

	@Override
	public List<CapgProduct> findAllProducts() throws InvalidInputException {
		return productRepo.findAll();
	}

}
