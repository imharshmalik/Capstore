package com.capgemini.capstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.CapgMerchant;
import com.capgemini.capstore.dao.ICapgFindMerchantDao;
import com.capgemini.capstore.exceptions.InvalidInputException;

@Service
public class CapgMerchantServiceImpl implements ICapgMerchantService{

	@Autowired
	ICapgFindMerchantDao merchantDao;
	
	//Search Customer
	public List<CapgMerchant> getMerchantByName(String merchantName) throws InvalidInputException {
		if (merchantDao.getMerchantByName(merchantName) != null)
			return merchantDao.getMerchantByName(merchantName);
		else
			throw new InvalidInputException();
	}
	
	public List<CapgMerchant> findAllMerchants() throws InvalidInputException{
		return merchantDao.findAllMerchants();
	}
}
