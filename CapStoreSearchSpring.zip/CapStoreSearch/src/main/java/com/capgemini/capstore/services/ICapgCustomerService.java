package com.capgemini.capstore.services;

import java.util.List;

import com.capgemini.capstore.beans.CapgCustomer;
import com.capgemini.capstore.exceptions.InvalidInputException;

public interface ICapgCustomerService {

	public List<CapgCustomer> getCustomerByName(String customerName) throws InvalidInputException;
	
	public List<CapgCustomer> findAllCustomers() throws InvalidInputException;
}
