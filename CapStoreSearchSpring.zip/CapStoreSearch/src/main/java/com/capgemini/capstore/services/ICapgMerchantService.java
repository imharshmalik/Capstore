package com.capgemini.capstore.services;

import java.util.List;
import com.capgemini.capstore.beans.CapgMerchant;
import com.capgemini.capstore.exceptions.InvalidInputException;

public interface ICapgMerchantService {

	public List<CapgMerchant> getMerchantByName(String merchantName) throws InvalidInputException;
	
	public List<CapgMerchant> findAllMerchants() throws InvalidInputException;
}
