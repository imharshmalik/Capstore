package com.capgemini.capstore.dao;

import java.util.List;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.exceptions.InvalidInputException;

public interface ICapgProductDao {

public CapgProduct getProductByName(String productName) throws InvalidInputException;
	
	public CapgProduct getProductById(int productId) throws InvalidInputException;
	
	public List<CapgProduct> getProductByType(String productType) throws InvalidInputException;
	
	public List<CapgProduct> getProductByCategory(String productCategory) throws InvalidInputException;
	
	public List<CapgProduct> getProductByMerchantId(int merchantId) throws InvalidInputException;
	
	public List<CapgProduct> findAllProducts() throws InvalidInputException;
}
